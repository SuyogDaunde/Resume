import {fetchMovieAvailability,fetchMovieList} from "./api.js"
